import importlib.util,json,concurrent.futures
from pathlib import Path
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('validation',p/'run-validation.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
jobs=json.loads((p/'extra-plan.json').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(v.run,jobs))
(p/'extra-results.json').write_text(json.dumps(results,indent=2)+'\n')
