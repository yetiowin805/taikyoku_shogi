import json,os,subprocess,concurrent.futures,hashlib,time
from pathlib import Path
root=Path('/home/frank/taikyoku_shogi');base=root/'benchmarks/nnue_tactics/v4-loss-corpus-20261010';out=base/'validation';out.mkdir(exist_ok=True);logs=out/'searches';logs.mkdir(exist_ok=True)
cases=json.loads((base/'shortlist.json').read_text());targets=[142,68,170,32,62,16,396,350,290,78,738,186,43,53,91,149,136,82,582,460,484,662,329,25,92,109,49,136,25,332,430,208]
replays={c['slot']:{x['ply']:x for x in map(json.loads,(base/'replays'/f"slot{c['slot']:04}.jsonl").read_text().splitlines())} for c in cases}
jobs=[]
for c,ply in zip(cases,targets):
 model=root/'models'/('nnue-v4' if c['agent'].endswith('_v4') else 'nnue-v4.5')/c['agent']/'model.json'
 for variant in ['deeper','played','fullq']:
  j=dict(case=c['id'],slot=c['slot'],ply=ply,color=c['color'],model=str(model),game=c['game'],variant=variant,depth=3 if variant=='fullq' else 4,played=replays[c['slot']][ply]['route'])
  jobs.append(j)
(out/'plan.json').write_text(json.dumps(jobs,indent=2)+'\n')
def run(j):
 tag=f"{j['case']}-p{j['ply']:04}-{j['variant']}";resultpath=logs/(tag+'.json');stdoutpath=logs/(tag+'.jsonl');stderrpath=logs/(tag+'.log')
 if resultpath.exists():return json.loads(resultpath.read_text())
 env={k:v for k,v in os.environ.items() if not k.startswith('TACTICAL_')};env['TAIKYOKU_DUMP_PV']='1'
 if j['variant']=='played':env['TACTICAL_ROOT']=j['played']
 if j['variant']=='fullq':env['TACTICAL_FLAGS']='fullq'
 start=time.monotonic()
 with stdoutpath.open('w') as stdout,stderrpath.open('w') as stderr:
  try:status=subprocess.run([os.environ.get('TACTICAL_ANALYZER',str(out/'bin'/'analyze_position')),j['game'],str(j['ply']),j['model'],str(j['depth']),'35000','--allow-historical'],stdout=stdout,stderr=stderr,env=env,timeout=45).returncode
  except subprocess.TimeoutExpired:status='watchdog_timeout'
 iterations=[json.loads(s) for s in stdoutpath.read_text().splitlines() if s.startswith('{')]
 for i in iterations:i['score_own']=i['score']*(1 if j['color']=='Black' else -1)
 pv=[json.loads(s[8:]) for s in stderrpath.read_text().splitlines() if s.startswith('PVTRACE ')]
 d=dict(**j,status=status,wall_seconds=round(time.monotonic()-start,2),iterations=iterations,pv=pv,completed_requested_depth=bool(iterations and iterations[-1]['completed_depth']>=j['depth']))
 resultpath.write_text(json.dumps(d,indent=2)+'\n');print(tag,status,iterations[-1] if iterations else 'NO RESULT',flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,jobs))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
