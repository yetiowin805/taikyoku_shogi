import json,os,subprocess,concurrent.futures,hashlib,time
from pathlib import Path
root=Path('/home/frank/taikyoku_shogi');out=root/'benchmarks/nnue_tactics/v4-loss-corpus-20261010';probe=out/'probes';probe.mkdir(exist_ok=True)
cases=json.load(open(out/'shortlist.json'));jobs=[]
for c in cases:
 if c['review_tier']!='primary':continue
 hits=[e for e in c['context'] if c['high']['ply']-2<=e['ply']<=c['low']['ply']+6 and e['color']!=c['color'] and any(p['color']==c['color'] and p['seed_value']>=648 for p in e['removed'])]
 target=hits[0]['ply']-1 if hits else c['low']['ply'];c['probe_ply']=target;c['probe_reason']='last own decision before observed major loss' if hits else 'recognition point'
 name=c['agent'];gen='nnue-v4' if name.endswith('_v4') else 'nnue-v4.5';model=root/'models'/gen/name/'model.json'
 for ply in sorted({target,max(1,target-2)}):
  for variant in ['baseline','fullq']:
   jobs.append(dict(case=c['id'],slot=c['slot'],ply=ply,variant=variant,depth=3,model=str(model),game=c['game']))
 # One deeper reference; not adjudicated ground truth.
 jobs.append(dict(case=c['id'],slot=c['slot'],ply=target,variant='deeper',depth=4,model=str(model),game=c['game']))
(out/'shortlist.json').write_text(json.dumps(cases,indent=2)+'\n')
(out/'probe-plan.json').write_text(json.dumps(jobs,indent=2)+'\n')
def run(j):
 model=Path(j['model'])
 if not model.exists():return dict(**j,status='missing_model')
 md=json.load(open(model));network=model.parent/md['weights']['nnue']['file']
 # Do not launch against a partial download.
 if hashlib.sha256(network.read_bytes()).hexdigest()!=md['weights']['nnue']['sha256']:return dict(**j,status='model_incomplete')
 tag=f"{j['case']}-p{j['ply']:04}-{j['variant']}";log=probe/(tag+'.log');res=probe/(tag+'.jsonl');env=os.environ.copy();env['TAIKYOKU_DUMP_PV']='1'
 if j['variant']=='fullq':env['TACTICAL_FLAGS']='fullq'
 started=time.monotonic()
 with res.open('w') as stdout,log.open('w') as stderr:
  try:status=subprocess.run([os.environ.get('TACTICAL_ANALYZER', '/tmp/slot817-results/analyze_position'),j['game'],str(j['ply']),j['model'],str(j['depth']),'45000','--allow-historical'],stdout=stdout,stderr=stderr,env=env,timeout=60).returncode
  except subprocess.TimeoutExpired:status='watchdog_timeout'
 iterations=[json.loads(line) for line in res.read_text().splitlines() if line.startswith('{')]
 pv=[json.loads(line[8:]) for line in log.read_text().splitlines() if line.startswith('PVTRACE ')]
 result=dict(**j,status=status,wall_seconds=round(time.monotonic()-started,2),iterations=iterations,pv=pv,model_sha256=hashlib.sha256(model.read_bytes()).hexdigest(),network_sha256=md['weights']['nnue']['sha256'])
 print(tag,status,iterations[-1] if iterations else 'NO RESULT',flush=True)
 return result
# Start 512-width tasks while the remaining model downloads; rerun incomplete tasks later.
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
 results=list(executor.map(run,jobs))
(out/'probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
